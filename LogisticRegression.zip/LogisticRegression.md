# Logistic Regression <br>- 분류를 위한회귀(Classification)
독립 변수의 선형 결합을 이용하여 사건의 발생 가능성을 예측하는데 사용되는 통계 기법이다.<br>
<br>
로지스틱 회귀의 목적은 일반적인 회귀 분석의 목표와 동일하게 종속 변수와 독립 변수간의 관계를 구체적인 함수로 나타내어 향후 예측 모델에 사용하는 것이다. 이는 독립 변수의 선형 결합으로 종속 변수를 설명한다는 관점에서는 선형 회귀 분석과 유사하다. 하지만 로지스틱 회귀는 선형 회귀 분석과는 다르게 종속 변수가 범주형 데이터를 대상으로 하며 입력 데이터가 주어졌을 때 해당 데이터의 결과가 특정 분류로 나뉘기 때문에 일종의 분류 (classification) 기법으로도 볼 수 있다.
<br><br>
흔히 <u>로지스틱 회귀는 종속변수가 이항형 문제(즉, 유효한 범주의 개수가 두개인 경우)를 지칭할 때 사용</u>된다.<br> 이외에, 두 개 이상의 범주를 가지는 문제가 대상인 경우엔 다항 로지스틱 회귀 (multinomial logistic regression) 또는 분화 로지스틱 회귀 (polytomous logistic regression)라고 하고 복수의 범주이면서 순서가 존재하면 서수 로지스틱 회귀 (ordinal logistic regression) 라고 한다.<br> 로지스틱 회귀 분석은 의료, 통신, 데이터마이닝과 같은 다양한 분야에서 분류 및 예측을 위한 모델로서 폭넓게 사용되고 있다.

## 이항 로지스틱 회귀<br>

**독립변수**<br>
- Self_Study_Daily(매일 집에서 공부한 시간)
- Tution_Monthly(한달에 받은 개인수업 시간)<br>

**종속변수**<br>
- Pass_Or_Fail: 0이면 Fail, 1이면 Pass<br>

### 1. 데이터 준비


```python
import pandas as pd
import numpy as np

df = pd.read_csv('Student-Pass-Fail-Data.csv')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Self_Study_Daily</th>
      <th>Tuition_Monthly</th>
      <th>Pass_Or_Fail</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7</td>
      <td>27</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>43</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7</td>
      <td>26</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8</td>
      <td>29</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>42</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>6</td>
      <td>22</td>
      <td>1</td>
    </tr>
    <tr>
      <th>996</th>
      <td>9</td>
      <td>30</td>
      <td>1</td>
    </tr>
    <tr>
      <th>997</th>
      <td>3</td>
      <td>39</td>
      <td>0</td>
    </tr>
    <tr>
      <th>998</th>
      <td>7</td>
      <td>25</td>
      <td>1</td>
    </tr>
    <tr>
      <th>999</th>
      <td>5</td>
      <td>37</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 3 columns</p>
</div>



### 2. 그래프를 이용해 데이터 살펴보기<br>
Self_Study_Daily와 Pass_Or_Fail의 관계를 살펴본다.


```python
%matplotlib inline
import matplotlib.pyplot as plt

plt.scatter(df['Self_Study_Daily'], df['Pass_Or_Fail'])
plt.show()

```


![png](output_4_0.png)


Pass_Or_Fail이 0과 1의 이산적인 값을 갖기 때문에
같은 점이 반복해서 찍히고 있다.<br>
그 위치에 점이 얼마나 찍혔는지 알 수가 없어서 분포를 파악하기가 매우 어렵다<br>
따라서, 앞에서 배운 KDE plot을 이용한다.


```python
import seaborn as sns
X_Fail = df.Self_Study_Daily[df.Pass_Or_Fail == 0]
X_Pass = df.Self_Study_Daily[df.Pass_Or_Fail == 1]

g = sns.kdeplot(X_Fail)
g = sns.kdeplot(X_Pass)
```


![png](output_6_0.png)


같은 방법으로 Tution_Monthly와 Pass_Or_Fail의 관계를 살펴본다.


```python
plt.scatter(df['Tuition_Monthly'], df['Pass_Or_Fail'])
plt.show()
```


![png](output_8_0.png)



```python
X_Fail = df.Tuition_Monthly[df.Pass_Or_Fail == 0]
X_Pass = df.Tuition_Monthly[df.Pass_Or_Fail == 1]

g = sns.kdeplot(X_Fail)
g = sns.kdeplot(X_Pass)
```


![png](output_9_0.png)


Self_Study_Daily와 Tuition_Monthly가 미치는 영향을 함께 볼 수 있는 방법은<br>
위에서 그린 KDE plot의 아이디어를 확장해서 2차원 그래프를 그리면 볼 수 있다.<br>
Pass_Or_Fail에 의해 데이터 셋이 둘로 나뉘기 때문에, x축과 y축에 Self_Study_Daily와 Tuition_Monthly를 놓고 scatter 그래프의 모양을 Pass_Or_Fail에 따라 다르게 그리면 이 셋 간의 관계를 한 눈에 보는 것이 가능하다.


```python
plt.scatter(df.Self_Study_Daily, df.Tuition_Monthly, c = df.Pass_Or_Fail)
plt.xlabel('Self Study Daily')
plt.ylabel('Tuition Monthly')
plt.show()
```


![png](output_11_0.png)


로지스틱 회귀분석은 위와 같은 그래프에서 서로 다른 종류의 점들을 가장 잘 구분하는 직선을 찾는 문제라고 할 수 있다.<br>

위 그래프는 각 점들이 겹쳐져 그려지기 때문에 보기가 어렵다.<br>
SNS 패키지의 KDE plot을 이용하면 아래와 같이 2차원에 대해서도 분포를 볼 수 있도록 그릴 수 있다.


```python
ax = sns.kdeplot(df.Self_Study_Daily[df.Pass_Or_Fail == 0], df.Tuition_Monthly[df.Pass_Or_Fail == 0]
                , cmap = 'Blues', shade=True, shade_lowest=False)

ax = sns.kdeplot(df.Self_Study_Daily[df.Pass_Or_Fail == 1], df.Tuition_Monthly[df.Pass_Or_Fail == 1],
                cmap = 'Greens', shade = True, shade_lowest=False)
```


![png](output_13_0.png)


- train set과 test set 준비


```python
from sklearn.model_selection import train_test_split

X = df.drop('Pass_Or_Fail', axis =1 )
y = df.Pass_Or_Fail

X_train,X_test,y_train,y_test = train_test_split(X,y, random_state=4)
print(X_train.shape, X_test.shape)
```

    (750, 2) (250, 2)
    

## 3. 이항 로지스틱 회귀분석 실시
Scikit-learn의 LogisticRegression을 이용한다. 사용법은 LinearRegression과 거의 유사하다.<br>
하지만, 로지스틱 회귀분석은 성능을 측정하기 위해 선형회귀분석과는 다른 지표를 사용한다.<br>
선형회귀분석은 예측값이 연속적이기 때문에 R2를 사용하지만, 로지스틱 회귀분석은 정확도(Accuracy)를 사용하며 이 값은 예측한 값이 원래값과 일치하는 비율을 의미한다.


```python
from sklearn.linear_model import LogisticRegression
LR_clf = LogisticRegression(solver='lbfgs')
LR_clf.fit(X_train, y_train)

print('Train set score: {:.3f}'.format(LR_clf.score(X_train, y_train)))
print('Test set score: {:.3f}'.format(LR_clf.score(X_test, y_test)))
```

    Train set score: 0.977
    Test set score: 0.968
    

## 4. 이항 로지스틱 회귀분석 예측 원리 이해
1. 선형회귀분석을 이용해 값을 예측한다. **decision_function**으로 확인 가능<br>
2. 예측된 값을 확률로 변환한다. **predict_proba**으로 확인 가능
3. 확률에 따라 값을 판별한다. **argmax**으로 확인 가능


```python
import numpy as np
np.set_printoptions(precision=3) #값이 소수점 이하 둘째자리까지만 나오도록 세팅
print('coef_', LR_clf.coef_) 
print('intercept_', LR_clf.intercept_)
```

    coef_ [[ 2.437 -0.744]]
    intercept_ [5.111]
    


```python
print(LR_clf.decision_function(X_test[:10]))
print(np.round(LR_clf.predict_proba(X_test[:10]),3))
print('각 행 별로 가장 높은 값을 가지는 index가 예측된 분류:', LR_clf.predict_proba(X_test[:10]).argmax(axis=1))
print('판별된 값:', LR_clf.predict(X_test[:10]))
```

    [  3.776   2.827   3.032 -13.412   3.571   3.571   3.981   4.725 -24.443
       3.032]
    [[0.022 0.978]
     [0.056 0.944]
     [0.046 0.954]
     [1.    0.   ]
     [0.027 0.973]
     [0.027 0.973]
     [0.018 0.982]
     [0.009 0.991]
     [1.    0.   ]
     [0.046 0.954]]
    각 행 별로 가장 높은 값을 가지는 index가 예측된 분류: [1 1 1 0 1 1 1 1 0 1]
    판별된 값: [1 1 1 0 1 1 1 1 0 1]
    

만일 내가 하루평균 7시간을 공부하고 한달평균 30시간 개인과외를 받으면 붙을 수 있을까?


```python
print(LR_clf.predict(np.asarray([[7,30]])))
```

    [0]
    

개인과외를 20으로 줄인다면?


```python
print(LR_clf.predict(np.asarray([[7,20]])))
```

    [1]
    

## 다항 로지싁 회귀
### 1. 데이터 준비
The Iris Dataset 사용<br>
iris: <u>붓꽃, setosa, versicolor, virginica</u> 세 종에 대한 데이터가 있다.<br>
측정 데이터: **꽃잎(petal)의 폭과 길이, 꽃받침(sepal)의 폭과 길이**<br>
목표: 측정 데이터를 이용해 종을 분류하고 예측할 수 있을까?<br><br>
참고:<br>
http://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_iris.html
<br>
http://scikit-learn.org/stable/auto_examples/datasets/plot_iris_dataset.html


```python
from sklearn.datasets import load_iris
iris = load_iris()
print(iris.DESCR) #boston['DESCR'] 도 가능
print(iris.data.shape, iris.target.shape)
print(iris.data[:5])
print(iris.target[:5])
```

    .. _iris_dataset:
    
    Iris plants dataset
    --------------------
    
    **Data Set Characteristics:**
    
        :Number of Instances: 150 (50 in each of three classes)
        :Number of Attributes: 4 numeric, predictive attributes and the class
        :Attribute Information:
            - sepal length in cm
            - sepal width in cm
            - petal length in cm
            - petal width in cm
            - class:
                    - Iris-Setosa
                    - Iris-Versicolour
                    - Iris-Virginica
                    
        :Summary Statistics:
    
        ============== ==== ==== ======= ===== ====================
                        Min  Max   Mean    SD   Class Correlation
        ============== ==== ==== ======= ===== ====================
        sepal length:   4.3  7.9   5.84   0.83    0.7826
        sepal width:    2.0  4.4   3.05   0.43   -0.4194
        petal length:   1.0  6.9   3.76   1.76    0.9490  (high!)
        petal width:    0.1  2.5   1.20   0.76    0.9565  (high!)
        ============== ==== ==== ======= ===== ====================
    
        :Missing Attribute Values: None
        :Class Distribution: 33.3% for each of 3 classes.
        :Creator: R.A. Fisher
        :Donor: Michael Marshall (MARSHALL%PLU@io.arc.nasa.gov)
        :Date: July, 1988
    
    The famous Iris database, first used by Sir R.A. Fisher. The dataset is taken
    from Fisher's paper. Note that it's the same as in R, but not as in the UCI
    Machine Learning Repository, which has two wrong data points.
    
    This is perhaps the best known database to be found in the
    pattern recognition literature.  Fisher's paper is a classic in the field and
    is referenced frequently to this day.  (See Duda & Hart, for example.)  The
    data set contains 3 classes of 50 instances each, where each class refers to a
    type of iris plant.  One class is linearly separable from the other 2; the
    latter are NOT linearly separable from each other.
    
    .. topic:: References
    
       - Fisher, R.A. "The use of multiple measurements in taxonomic problems"
         Annual Eugenics, 7, Part II, 179-188 (1936); also in "Contributions to
         Mathematical Statistics" (John Wiley, NY, 1950).
       - Duda, R.O., & Hart, P.E. (1973) Pattern Classification and Scene Analysis.
         (Q327.D83) John Wiley & Sons.  ISBN 0-471-22361-1.  See page 218.
       - Dasarathy, B.V. (1980) "Nosing Around the Neighborhood: A New System
         Structure and Classification Rule for Recognition in Partially Exposed
         Environments".  IEEE Transactions on Pattern Analysis and Machine
         Intelligence, Vol. PAMI-2, No. 1, 67-71.
       - Gates, G.W. (1972) "The Reduced Nearest Neighbor Rule".  IEEE Transactions
         on Information Theory, May 1972, 431-433.
       - See also: 1988 MLC Proceedings, 54-64.  Cheeseman et al"s AUTOCLASS II
         conceptual clustering system finds 3 classes in the data.
       - Many, many more ...
    (150, 4) (150,)
    [[5.1 3.5 1.4 0.2]
     [4.9 3.  1.4 0.2]
     [4.7 3.2 1.3 0.2]
     [4.6 3.1 1.5 0.2]
     [5.  3.6 1.4 0.2]]
    [0 0 0 0 0]
    


```python
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(iris.data, iris.target, random_state=7, test_size=0.2)
print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)
```

    (120, 4) (120,)
    (30, 4) (30,)
    

### 2. 데이터 살펴보기


```python
%matplotlib inline
import matplotlib.pyplot as plt

fig, axes = plt.subplots(2, 2, figsize=(10, 7)) #총 네개의 독립변수가 있으므로 2x2 타일을 이용
#y = iris.target
#y = iris.target.astype('str') # target data의 type을 string으로 변환
y = iris.target # target data의 type을 string으로 변환

for i, ax in enumerate(axes.ravel()): #나누어진 각 subplot에 대해
    if i < iris.data.shape[1]:
        x = iris.data[:,i]

        ax.set_title(iris.feature_names[i])
        ax.scatter(x, y)
plt.show()
```


![png](output_29_0.png)



```python
plt.scatter(iris.data[:, 0], iris.data[:, 1], c=iris.target)
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.show()
```


![png](output_30_0.png)


알아보기 쉽게 legend 표시


```python
plt.scatter(iris.data[iris.target == 0, 0], iris.data[iris.target == 0, 1], marker='o')
plt.scatter(iris.data[iris.target == 1, 0], iris.data[iris.target == 1, 1], marker='+')
plt.scatter(iris.data[iris.target == 2, 0], iris.data[iris.target == 2, 1], marker='v')

plt.legend(['Iris-Setosa', 'Iris-Versicolour', 'Iris-Virginica'])
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.show()
```


![png](output_32_0.png)


꽃잎(petal)의 폭, 길이와 종의 관계는?


```python
plt.scatter(iris.data[iris.target == 0, 2], iris.data[iris.target == 0, 3], marker='o')
plt.scatter(iris.data[iris.target == 1, 2], iris.data[iris.target == 1, 3], marker='+')
plt.scatter(iris.data[iris.target == 2, 2], iris.data[iris.target == 2, 3], marker='v')

plt.legend(['Iris-Setosa', 'Iris-Versicolour', 'Iris-Virginica'])
plt.xlabel(iris.feature_names[2])
plt.ylabel(iris.feature_names[3])
plt.show()
```


![png](output_34_0.png)


## 3. 로지스틱 회귀분석 실시
그래프에서 종의 구분에 가장 큰 영향을 미칠 것으로 예상되는 petal length로 로지스틱회귀분석을 실시


```python
from sklearn.linear_model import LogisticRegression
LR_clf = LogisticRegression(solver='lbfgs', multi_class='auto')
LR_clf.fit(X_train[:, 2].reshape(-1, 1), y_train)
```




    LogisticRegression()




```python
print('Train set score: {:.3f}'.format(LR_clf.score(X_train[:, 2].reshape(-1, 1), y_train)))
print('Test set score: {:.3f}'.format(LR_clf.score(X_test[:, 2].reshape(-1, 1), y_test)))
```

    Train set score: 0.975
    Test set score: 0.867
    

전체 데이터를 다 사용하면 결과가 좋아질까?


```python
LR_clf = LogisticRegression(solver='lbfgs', multi_class='auto', max_iter=1000)
LR_clf.fit(X_train, y_train)
```




    LogisticRegression(max_iter=1000)




```python
print('Train set score: {:.3f}'.format(LR_clf.score(X_train, y_train)))
print('Test set score: {:.3f}'.format(LR_clf.score(X_test, y_test)))
```

    Train set score: 0.992
    Test set score: 0.867
    

위 결과를 놓고 보면 적어도 test set에서는 petal length 만으로도 전체 features와 동일한 결과를 낸다.<br>
그러나 train set에 대한 score가 높은 것을 보면 결과를 향상시킬 가능성이 있어 보인다.


```python
print(LR_clf.predict(X_test[:20])) #예측 결과와 실제 결과 확인
print(y_test[:20])
```

    [2 1 0 1 1 0 1 1 0 1 2 1 0 2 0 2 2 2 0 0]
    [2 1 0 1 2 0 1 1 0 1 1 1 0 2 0 1 2 2 0 0]
    

y값에 대한 이름 리스트(혹은 딕셔너리도 가능)를 만들어 사용




```python
labels = ['Iris-Setosa', 'Iris-Versicolour', 'Iris-Virginica']
print([labels[p] for p in LR_clf.predict(X_test[:10])])
```

    ['Iris-Virginica', 'Iris-Versicolour', 'Iris-Setosa', 'Iris-Versicolour', 'Iris-Versicolour', 'Iris-Setosa', 'Iris-Versicolour', 'Iris-Versicolour', 'Iris-Setosa', 'Iris-Versicolour']
    

### 4. 다항 로지스틱 회귀분석 원리에 대한 이해
y의 각 값 0, 1, 2에 대해 각각 회귀분석을 실시하여 확률을 예측하고, 그 확률값이 가장 높은 것을 선택하여 분류를 결정


```python
import numpy as np
np.set_printoptions(precision=3) #값이 소수점 이하 둘째자리까지만 나오도록 세팅
print('coef_', LR_clf.coef_) # 0, 1, 2 각각에 대해 네 개의 계수
print('intercept_', LR_clf.intercept_) # 0, 1, 2각각에 대한 상수
```

    coef_ [[-0.437  0.854 -2.308 -0.993]
     [ 0.342 -0.717 -0.097 -0.899]
     [ 0.095 -0.137  2.406  1.892]]
    intercept_ [  9.353   3.799 -13.152]
    


```python
print(LR_clf.decision_function(X_test[:10]))
print(np.round(LR_clf.predict_proba(X_test[:10]),3))
print('Prediction Results:', LR_clf.predict_proba(X_test[:10]).argmax(axis=1))
```

    [[-4.225  1.554  2.671]
     [-2.323  1.711  0.613]
     [ 6.857  2.605 -9.462]
     [-2.411  1.779  0.632]
     [-2.73   1.718  1.012]
     [ 6.051  3.294 -9.345]
     [-3.817  2.113  1.704]
     [-1.776  2.203 -0.427]
     [ 6.266  2.669 -8.935]
     [-2.59   1.909  0.68 ]]
    [[0.001 0.246 0.753]
     [0.013 0.74  0.247]
     [0.986 0.014 0.   ]
     [0.011 0.75  0.238]
     [0.008 0.664 0.328]
     [0.94  0.06  0.   ]
     [0.002 0.6   0.398]
     [0.017 0.917 0.066]
     [0.973 0.027 0.   ]
     [0.009 0.767 0.224]]
    Prediction Results: [2 1 0 1 1 0 1 1 0 1]
    

predict_proba 은 확률의 역할을 하므로 각 행의 값을 다 합치면 1이 됨


```python
proba = LR_clf.predict_proba(X_test[:10])
import numpy as np
np.sum(proba, axis=1)
```




    array([1., 1., 1., 1., 1., 1., 1., 1., 1., 1.])




```python

```
