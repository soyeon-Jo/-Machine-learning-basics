# Classfication
SVM, 결정트리, Random Forest, Gradient Boosting 
<br>
## 1. 데이터 준비


```python
from sklearn.datasets import load_breast_cancer
cancer = load_breast_cancer()

print(cancer.DESCR)
print(cancer.data.shape, cancer.target.shape)
```

    .. _breast_cancer_dataset:
    
    Breast cancer wisconsin (diagnostic) dataset
    --------------------------------------------
    
    **Data Set Characteristics:**
    
        :Number of Instances: 569
    
        :Number of Attributes: 30 numeric, predictive attributes and the class
    
        :Attribute Information:
            - radius (mean of distances from center to points on the perimeter)
            - texture (standard deviation of gray-scale values)
            - perimeter
            - area
            - smoothness (local variation in radius lengths)
            - compactness (perimeter^2 / area - 1.0)
            - concavity (severity of concave portions of the contour)
            - concave points (number of concave portions of the contour)
            - symmetry
            - fractal dimension ("coastline approximation" - 1)
    
            The mean, standard error, and "worst" or largest (mean of the three
            worst/largest values) of these features were computed for each image,
            resulting in 30 features.  For instance, field 0 is Mean Radius, field
            10 is Radius SE, field 20 is Worst Radius.
    
            - class:
                    - WDBC-Malignant
                    - WDBC-Benign
    
        :Summary Statistics:
    
        ===================================== ====== ======
                                               Min    Max
        ===================================== ====== ======
        radius (mean):                        6.981  28.11
        texture (mean):                       9.71   39.28
        perimeter (mean):                     43.79  188.5
        area (mean):                          143.5  2501.0
        smoothness (mean):                    0.053  0.163
        compactness (mean):                   0.019  0.345
        concavity (mean):                     0.0    0.427
        concave points (mean):                0.0    0.201
        symmetry (mean):                      0.106  0.304
        fractal dimension (mean):             0.05   0.097
        radius (standard error):              0.112  2.873
        texture (standard error):             0.36   4.885
        perimeter (standard error):           0.757  21.98
        area (standard error):                6.802  542.2
        smoothness (standard error):          0.002  0.031
        compactness (standard error):         0.002  0.135
        concavity (standard error):           0.0    0.396
        concave points (standard error):      0.0    0.053
        symmetry (standard error):            0.008  0.079
        fractal dimension (standard error):   0.001  0.03
        radius (worst):                       7.93   36.04
        texture (worst):                      12.02  49.54
        perimeter (worst):                    50.41  251.2
        area (worst):                         185.2  4254.0
        smoothness (worst):                   0.071  0.223
        compactness (worst):                  0.027  1.058
        concavity (worst):                    0.0    1.252
        concave points (worst):               0.0    0.291
        symmetry (worst):                     0.156  0.664
        fractal dimension (worst):            0.055  0.208
        ===================================== ====== ======
    
        :Missing Attribute Values: None
    
        :Class Distribution: 212 - Malignant, 357 - Benign
    
        :Creator:  Dr. William H. Wolberg, W. Nick Street, Olvi L. Mangasarian
    
        :Donor: Nick Street
    
        :Date: November, 1995
    
    This is a copy of UCI ML Breast Cancer Wisconsin (Diagnostic) datasets.
    https://goo.gl/U2Uwz2
    
    Features are computed from a digitized image of a fine needle
    aspirate (FNA) of a breast mass.  They describe
    characteristics of the cell nuclei present in the image.
    
    Separating plane described above was obtained using
    Multisurface Method-Tree (MSM-T) [K. P. Bennett, "Decision Tree
    Construction Via Linear Programming." Proceedings of the 4th
    Midwest Artificial Intelligence and Cognitive Science Society,
    pp. 97-101, 1992], a classification method which uses linear
    programming to construct a decision tree.  Relevant features
    were selected using an exhaustive search in the space of 1-4
    features and 1-3 separating planes.
    
    The actual linear program used to obtain the separating plane
    in the 3-dimensional space is that described in:
    [K. P. Bennett and O. L. Mangasarian: "Robust Linear
    Programming Discrimination of Two Linearly Inseparable Sets",
    Optimization Methods and Software 1, 1992, 23-34].
    
    This database is also available through the UW CS ftp server:
    
    ftp ftp.cs.wisc.edu
    cd math-prog/cpo-dataset/machine-learn/WDBC/
    
    .. topic:: References
    
       - W.N. Street, W.H. Wolberg and O.L. Mangasarian. Nuclear feature extraction 
         for breast tumor diagnosis. IS&T/SPIE 1993 International Symposium on 
         Electronic Imaging: Science and Technology, volume 1905, pages 861-870,
         San Jose, CA, 1993.
       - O.L. Mangasarian, W.N. Street and W.H. Wolberg. Breast cancer diagnosis and 
         prognosis via linear programming. Operations Research, 43(4), pages 570-577, 
         July-August 1995.
       - W.H. Wolberg, W.N. Street, and O.L. Mangasarian. Machine learning techniques
         to diagnose breast cancer from fine-needle aspirates. Cancer Letters 77 (1994) 
         163-171.
    (569, 30) (569,)
    


```python
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(cancer.data,cancer.target,
                                                   random_state=1)

print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)
                                                   
```

    (426, 30) (426,)
    (143, 30) (143,)
    

## 2. 데이터 살펴보기


```python
%matplotlib inline
import matplotlib.pyplot as plt

fig,axes = plt.subplots(10,3,figsize=(20,15))
y = cancer.target

for i,ax in enumerate(axes.ravel()):
    if i < cancer.data.shape[1]:
        x = cancer.data[:,i]
        
        ax.scatter(x,y)
        ax.set_title(cancer.feature_names[i])

plt.show()
```


![png](output_4_0.png)


히스토그램을 이용해 시각화 향상


```python
%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np

fig,axes = plt.subplots(10,3,figsize=(10,20))

malignant = cancer.data[cancer.target == 0]
benign = cancer.data[cancer.target == 1]

ax = axes.ravel()
colors = ['blue','yellow']

for i in range(30):
    _,bins = np.histogram(cancer.data[:,i],bins=50)
    ax[i].hist(malignant[:,i], bins=bins, color=colors[0], alpha=.5)    
    ax[i].hist(benign[:,i], bins=bins, color=colors[1], alpha=.5)
    
    ax[i].set_title(cancer.feature_names[i])
    ax[i].set_yticks(())
    
ax[0].set_xlabel("Feature magnitude")
ax[0].set_ylabel("Frequency")
ax[0].legend(["malignant",'benign'], loc="best")
fig.tight_layout()
```


![png](output_6_0.png)


##### seaborn package로 살펴보기
pairplot을 이용해 한 변수의 kde, 두 변수 간의 2차원 scatter graph를 쉽게 볼 수 있다.


```python
import seaborn as sns
from scipy import stats
import numpy as np
import pandas as pd

df = pd.DataFrame(np.c_[cancer['data'], cancer['target']],
                 columns= np.append(cancer['feature_names'],['target']))

g = sns.pairplot(df, height=3, hue='target', vars=['mean radius','mean texture'])
```


![png](output_8_0.png)



```python
import seaborn as sns

fig,axes = plt.subplots(10,3, figsize=(20,30))

X = cancer.data
Y = cancer.target

for i,a in enumerate(axes.ravel()):
    if i < X.shape[1]:
        sns.kdeplot(X[Y == 0,i], ax=a, color= 'green')
        sns.kdeplot(X[y == 1,i], ax=a, color= 'black')
        a.set_title(cancer.feature_names[i])

plt.show()
```


![png](output_9_0.png)



```python
from sklearn.linear_model import LogisticRegression

LR_clf = LogisticRegression(max_iter=10000, solver='lbfgs')
LR_clf.fit(X_train, y_train)
```




    LogisticRegression(max_iter=10000)




```python
print('Train set score: {:.3f}'.format(LR_clf.score(X_train, y_train)))
print('Test set score: {:.3f}'.format(LR_clf.score(X_test, y_test)))
```

    Train set score: 0.965
    Test set score: 0.944
    

## 3. K-최근접 이웃
가장 가까운 훈련 데이터 포인트 k개를 찾아 평균을 계산하여 예측에 사용한다.
<br>
**n_neighbors** 
- 사용할 이웃의 수, 커질수록 훈련 데이터에 대한 예측은 좋아진다.
- 훈련과 관계없이 테스트 세트의 정확도는 너무 작거나 너무 크면 좋지 않은 경향이 있어, 적절하게 선택해야 한다.
- 가까운 점들을 기반하여 판단하기 때문에 **홀수**로 설정하는 것이 좋다.

**KNN 특징**
- 이해가 쉽고 별다른 노력 없이 좋은 성능을 보이는 경우가 있다.
- 훈련 세트가 커지면 예측이 느려지고 특성이 많은 경우에는 잘 동작하지 않을 수 있다.
- 많은 특성이 0인 데이터에서는 특히 성능이 낮다.
<br>


```python
plt.scatter(X_train[y_train == 0,0], X_train[y_train == 0,1], marker ='o')
plt.scatter(X_train[y_train == 1,0], X_train[y_train == 1,1], marker = '+')
plt.scatter(X_test[0,0], X_test[0,1], marker='v')

plt.legend(['Malignant','Benign','Test'])
plt.xlabel(cancer.feature_names[0])
plt.ylabel(cancer.feature_names[1])
plt.show()
```


![png](output_13_0.png)



```python
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=3) 
knn.fit(X_train,y_train)

print('K-neighbor train set score:{:.3f}'.format(knn.score(X_train,y_train)))
print('K-neighbor test set score:{:.3f}'.format(knn.score(X_test,y_test)))
```

    K-neighbor train set score:0.946
    K-neighbor test set score:0.923
    

### 4. 결정트리(Decision Tree)
결정 트리(decision tree)는 의사 결정 규칙과 그 결과들을 트리 구조로 도식화한 의사 결정 지원 도구의 일종이다. 
- 결정 트리는 운용 과학, 그 중에서도 의사 결정 분석에서 목표에 가장 가까운 결과를 낼 수 있는 전략을 찾기 위해 주로 사용된다.<br>

-**특성**<br>
- 훈련 데이터에 과대적합되는 경향이 있다.
- 알고리즘의 특성 상 외삽(extrapolation), 즉 훈련 데이터 범위 밖의 포인트에 대해서는 예측을 할 수 없다.


```python
from sklearn.tree import DecisionTreeClassifier
tree = DecisionTreeClassifier(random_state=7)

tree.fit(X_train, y_train)

print('Decision Tree train set score: {:.3f}'.format(tree.score(X_train,y_train)))
print('Decision Tree test set score: {:.3f}'.format(tree.score(X_test,y_test)))
```

    Decision Tree train set score: 1.000
    Decision Tree test set score: 0.944
    


```python
from sklearn.tree import export_graphviz
export_graphviz(tree,out_file='tree.dot', class_names=['악성','양성'],
               impurity=False, filled=True)
```

#### Graphviz 설치방법
1. 윈도우용 graphviz 패키지 설치<br>
https://graphviz.gitlab.io/download/ <br>

Stable 2.38 Windows install packages<br>

2. 환경변수에 Path 추가
C:\Program Files (x86)\Graphviz2.38\bin<br>

cmd 창에서 SET 을 치고 Path의 내용 확인, 없으면 재부팅<br>

3. conda 명령어를 이용해 python graphviz 모듈 설치 <br>
conda install -c conda-forge python-graphviz<br>


```python
import graphviz

with open('tree.dot', encoding='utf8') as f:
    dot_graph = f.read()
display(graphviz.Source(dot_graph))
```


![svg](output_19_0.svg)


**트리의 특성 중요도: 각 특성이 분류에 기여한 정도<br>
<br>featureimportances**, 이 값이 0이면 분류에서 사용되지 않았다는 뜻이나, 다른 특성과 겹쳐서 그럴 수도 있으므로 특성이 의미 없다는 것을 나타내지는 않는다


```python
import numpy as np
np.set_printoptions(precision=3) #값이 소수점 이하 둘째자리까지만 나오도록 세팅

print('특성 중요도: \n{}\n'.format(tree.feature_importances_))

for feature, value in zip(cancer.feature_names, tree.feature_importances_):
    print('%s: %.3f' % (feature, value))
```

    특성 중요도: 
    [0.    0.022 0.    0.    0.    0.    0.    0.021 0.    0.008 0.003 0.
     0.    0.007 0.    0.    0.    0.036 0.    0.    0.    0.081 0.743 0.022
     0.01  0.    0.    0.047 0.    0.   ]
    
    mean radius: 0.000
    mean texture: 0.022
    mean perimeter: 0.000
    mean area: 0.000
    mean smoothness: 0.000
    mean compactness: 0.000
    mean concavity: 0.000
    mean concave points: 0.021
    mean symmetry: 0.000
    mean fractal dimension: 0.008
    radius error: 0.003
    texture error: 0.000
    perimeter error: 0.000
    area error: 0.007
    smoothness error: 0.000
    compactness error: 0.000
    concavity error: 0.000
    concave points error: 0.036
    symmetry error: 0.000
    fractal dimension error: 0.000
    worst radius: 0.000
    worst texture: 0.081
    worst perimeter: 0.743
    worst area: 0.022
    worst smoothness: 0.010
    worst compactness: 0.000
    worst concavity: 0.000
    worst concave points: 0.047
    worst symmetry: 0.000
    worst fractal dimension: 0.000
    

**Lasso**와 비교<br>
Lasso도 영향을 미치지 않는 특성의 계수를 0으로 만드므로 비교가 가능하다.

- **결정트리 복잡도 제어하기**<br>
트리의 깊이가 무한하게 깊어지지 않고 적절한 선에서 멈추도록 제한할 수 있다.


```python
tree = DecisionTreeClassifier(max_depth=4, random_state=7)
tree.fit(X_train, y_train)
print('Decision Tree train set score: {:.3f}'.format(tree.score(X_train, y_train)))
print('Decision Tree test set score: {:.3f}'.format(tree.score(X_test, y_test)))
```

    Decision Tree train set score: 0.998
    Decision Tree test set score: 0.951
    
