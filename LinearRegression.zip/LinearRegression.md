# 회귀분석(Linear Regression)<br>
 선형 회귀(線型回歸, 영어: linear regression)는 종속 변수 y와 한 개 이상의 독립 변수 (또는 설명 변수) X와의 선형 상관 관계를 모델링하는 회귀분석 기법이다. 한 개의 설명 변수에 기반한 경우에는 단순 선형 회귀, 둘 이상의 설명 변수에 기반한 경우에는 다중 선형 회귀라고 한다.<br>
 <br>
 값을 예측하는 것이 목적일 경우, 선형 회귀를 사용해 데이터에 적합한 예측 모형을 개발한다. 개발한 선형 회귀식을 사용해 y가 없는 x값에 대해 y를 예측하기 위해 사용할 수 있다. 종속 변수 y와 이것과 연관된 독립 변수 X1, ..., Xp가 존재하는 경우에, 선형 회귀 분석을 사용해 Xj와 y의 관계를 정량화할 수 있다. Xj는 y와 전혀 관계가 없을 수도 있고, 추가적인 정보를 제공하는 변수일 수도 있다. 일반적으로 최소제곱법(least square method)을 사용해 선형 회귀 모델을 세운다. 최소제곱법 외에 다른 기법으로도 선형 회귀 모델을 세울 수 있다. 손실 함수(loss fuction)를 최소화 하는 방식으로 선형 회귀 모델을 세울 수도 있다. 최소제곱법은 선형 회귀 모델 뿐 아니라, 비선형 회귀 모델에도 적용할 수 있다. 최소제곱법과 선형 회귀는 가깝게 연관되어 있지만, 그렇다고 해서 동의어는 아니다.


#### 용어 정리
1. **독립변수**:<br>
예측에 사용하고자 하는 변수, 즉 영향을 미칠 것으로 생각하는 변수를 말한다. 예를 들어 키가 몸무게에 영향을 미칠 것이라고 생각한다면 키가 독립변수이다.<br>
2. **종속변수**:<br>
예측하고자 하는 변수, 즉 영향을 받는다고 생각하는 변수를 말한다. 키가 몸무게에 영향을 미친다고 생각한다면 몸무게가 종속변수이다.<br>
3. **설명력 (R square)**:<br>
정확히는 모든 데이터에 대해, 편차(실제값과 평균과의 차이)의 제곱합에 대한 잔차(실제값과 예측값과의 차이)의 제곱합의 비중을 1에서 뺀 값. <br>
<u>독립변수가 종속변수를 얼마나 설명해주는가에 대한 지수.</u><br>
이 값이 1이면 독립변수가 종속변수를 100% 설명하고, 0이면 하나도 설명하지 못한다고 할 수 있다. 즉 0이면 서로 아무런 연관성이 없기 때문에 예측이 불가능하고 1이면 100% 정확하게 예측이 가능하다는 것을 의미한다.

### 1.<br> scikit learn에서 제공하는 Boston데이터 로드 & train/test 분리<br>
1. sklearn.datasets에서 boston 데이터를 읽어온다.
2. train_test_split을 이용하여 train set과 test set으로 분리한다.
3. 분리된 data set의 크기를 확인한다.



```python
from sklearn.datasets import load_boston
boston = load_boston()

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(boston.data,boston.target,random_state=7,test_size=0.2)

print(X_train.shape,y_train.shape)
print(X_test.shape,y_test.shape)
```

    (404, 13) (404,)
    (102, 13) (102,)
    

### 2. 그래프 그리기
그래프를 통해 데이터에 대한 정보를 직관적으로 확인한다.<br>
boston data set에서 X에 해당하는 각각의 값과 y의 값으로 그래프를 그려서 각 x값과 y의 관계를 직관적으로 살펴본다.



```python
%matplotlib inline
import matplotlib.pyplot as plt

fig,axes = plt.subplots(5,3,figsize=(15,20))
y = boston.target

for i,ax in enumerate(axes.ravel()):
    if i < boston.data.shape[1]:
        x = boston.data[:,i]
        
        ax.set_title(boston.feature_names[i])
        ax.scatter(x,y)
plt.show()
```


![png](output_5_0.png)


## Sklearn LinearRegression
참고하기<br>
http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html<br>

**coefficient**: indepenent variables의 계수<br>
**intercept**: 상수 (bias)<br>
Sklearn이 제공하는 **LinearRegression**을 이용하여 회귀분석을 실시<br>
<br>
## 단순회귀분석(Simple linear regression)
### sklearn 회귀분석 순서
1. 원하는 **클래스 import**
2. **객체 생성**
3. **fit() 적용** : 모형 생성, 즉 데이터를 가장 잘 설명하는 선형식 - 쉽게 말해서 직선을 찾는다. fit()이 수행되면 기울기와 절편이 결정된다.
4. **모형 기본정보 확인** : fit()에서 결정된 기울기, 절편 등을 확인한다.
5. **score()로 성능 검사** : R2(R square)라고 해서 모형의 설명력을 나타내는 수치를 계산한다.
6. **predict()로 예측** : 새로운 독립변수를 이용하여 종속변수를 예측한다.<br>
<br><br>

위에서 직관적으로 살펴본 그래프들 중에서 연관성이 높아보이는 RM부터 시작한다.


```python
boston.data[:,5]#RM만 가져오기
```


```python
from sklearn.linear_model import LinearRegression

lr = LinearRegression()
lr.fit(X_train[:,5].reshape(-1,1),y_train) #reshape 적용
```




    LinearRegression()



#### reshape에 대해


```python
import numpy as np
a = np.array([[1, 2], [3, 4], [5, 6]])
print(a.shape)
a
```

    (3, 2)
    




    array([[1, 2],
           [3, 4],
           [5, 6]])




```python
a.reshape((2, 3))
#np.reshape(a, (2, 3))
```




    array([[1, 2, 3],
           [4, 5, 6]])




```python
a.reshape((-1, 3)) # -1이면 다른 차원을 적용하고 나서 결정되는 값으로 자동 적용
```




    array([[1, 2, 3],
           [4, 5, 6]])



다시 돌아와서<br>
- 모형의 기본 정보 보기


```python
print('coef_', lr.coef_) #계수(기울기)
print('intercept',lr.intercept_)# 상수
```

    coef_ [9.79620171]
    intercept -38.907661826429276
    

- 모형의 성능 살펴보기


```python
print('R2 score for train set: {:.3f}', lr.score(X_train[:,5].reshape(-1,1), y_train))
#train set에 대한 적합도 (모형이 얼마나 잘 맞는지)
```

    R2 score for train set: {:.3f} 0.5608802132974211
    

- test set에 대한 예측


```python
P_test = lr.predict(X_test[:,5].reshape(-1,1))
print('prediction',P_test)
print('R2 score for test set', lr.score(X_test[:,5].reshape(-1,1),y_test))
```

    prediction [23.73904812 18.84094726 20.68263318 19.36994216 19.44831177 13.49222113
     22.11287863 23.94476835 22.71044694 19.39933076  8.89780253 31.26253103
     22.01491662 22.11287863 34.11322573 24.15048859 25.64930745 29.48941852
     19.37973836 19.95771426 24.61091007 29.43064131 35.6414332  16.00004877
      9.3484278  27.53017818 33.78015487 27.6477326  23.54312408 25.40440241
     22.32839507 28.40204013 30.43965009 25.01255434 34.26996496 18.61563462
     17.85153089 27.20690352 20.97651924 28.65674138 23.95456456 26.22728335
     18.4686916  27.52038198 20.66304078 23.59210509 22.4753381  20.96672303
     21.3585711  -1.06493461 25.24766318 22.22063685 17.48907143 47.1029892
     24.38559743 21.11366606 19.16422192 21.9169546  20.99611164 18.4588954
     19.14462952 32.86910811 17.3323322  19.55606999 18.43930299 39.79502272
     23.89578735 23.51373548 20.27119271 26.09013653 22.82800136 18.08663973
     16.56822847 33.17279037 22.99453679 22.11287863 17.05803855 21.26060909
     28.43142874 20.57487497 33.51565743 24.87540752 22.24022926 18.64502323
     23.71945572 26.05095172 23.6214937  17.93969671 31.47804747 21.28999769
      9.77946068 36.38594453 34.75977504 23.0631102  22.54391151 18.41971059
     24.71866829 11.591758   16.11760319 26.99138709 26.28606056 18.03765872]
    R2 score for test set 0.14443708697515478
    

결과를 보면 train set과 test set에 대한 R2 값이 서로 많이 다른 것을 볼 수 있다.<br>
이는 일반화 성능이 많이 부족하거나, test set이 매우 운이 없게 만들어졌다는 것을 의미한다.<br>
<br>
- train set에 대한 그래프


```python
Y_predict = lr.predict(X_train[:,5].reshape(-1,1))

plt.xlabel(boston.feature_names[5])
plt.ylabel('Value')

plt.scatter(X_train[:,5],y_train, color='green') #실제 값
plt.plot(X_train[:,5],Y_predict, color='yellow', linewidth=3) #예측된 값

plt.show()
```


![png](output_20_0.png)


- test set에 대한 그래프


```python
Y_predict = lr.predict(X_test[:,5].reshape(-1,1))

plt.xlabel(boston.feature_names[5])
plt.ylabel('Value')

plt.scatter(X_test[:,5].reshape(-1,1), y_test, color='black')
plt.plot(X_test[:,5], Y_predict, color='blue',lw=4)

plt.show()
```


![png](output_22_0.png)


## 다중회귀분석(Multiple linear regression)
독립변수가 여러 개인 회귀모형<br>
보스톤 데이터 셋에서 전체 feature를 전부 사용.


```python
lr = LinearRegression().fit(X_train,y_train)
print(lr)
```

    LinearRegression()
    


```python
print('coef_', lr.coef_)
print('intercept_', lr.intercept_)
```

    coef_ [-1.24649091e-01  3.04735052e-02  2.17990089e-02  2.79225761e+00
     -1.52135247e+01  5.27249266e+00 -1.10577742e-02 -1.27320872e+00
      2.65804711e-01 -1.15043029e-02 -9.19571148e-01  1.01624292e-02
     -3.89712044e-01]
    intercept_ 23.554245467591464
    

- 예측결과와 실제값과의 관계를 그래프로 확인한다.
- 독립변수가 여러개이기 때문에 독립변수-종속변수 관계로 그래프를 그리기 어렵다.
- 따라서 실제 값을 X축에 놓고 예측된 값을 Y축으로 해서 그래프를 그리고 적합도를 직관적으로 볼 수 있다.


```python
predicted = lr.predict(X_train)

fig,ax =plt.subplots()
ax.scatter(y_train, predicted, edgecolors=(0,0,0)) #실제값과 예측값으로 점을 찍어 표시
ax.plot([y_train.min(),y_train.max()],[y_train.min(),y_train.max()],'k--',lw=4)#실제값과 예측값이 같은 지점을 연결해서 선을 표시 

ax.set_xlabel('Measured')
ax.set_ylabel('Predicted')
plt.show()
```


![png](output_27_0.png)



```python
print('R2 score for tain set: {:.3f}'.format(lr.score(X_train,y_train)))
print('R2 score for test set: {:.3f}'.format(lr.score(X_test,y_test)))
```

    R2 score for tain set: 0.770
    R2 score for test set: 0.579
    

## 특성 스케일링(feature scaling)<br>
: 데이터 변환 혹은 표준화<br>
- 어떤 머신러닝 알고리즘은 독립변수들의 스케일이 많이 다르면 잘 작동하지 않는다. 따라서 일정한 범위로 변수들을 조정할 필요가 있다.
- StandardScaler는 변수의 값들을 표준화시켜준다.(표준화는 평균으로 빼고 표준편차로 나누는 것을 의미)
- 다른 스케일링 방식으로 min-max scaling이 있는데, 이는 최소값을 뺀 후, 최대값과 최소값의 차이로 나누어 준다.
- 그 결과, 값을 0과 1 사이로 변환하고 min-max에 비해 standardize는 이상치에 더 강하다는 장점이 있음


```python
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler().fit(X_train)

print('scaler mean:', scaler.mean_)
print('scaler variance', scaler.var_)

scaled_X_train = scaler.transform(X_train)
scaled_X_test = scaler.transform(X_test)
```

    scaler mean: [3.40301918e+00 1.13886139e+01 1.10690099e+01 6.93069307e-02
     5.51701980e-01 6.27081683e+00 6.83544554e+01 3.81904455e+00
     9.09158416e+00 4.01945545e+02 1.83868812e+01 3.59049653e+02
     1.27629455e+01]
    scaler variance [6.72975672e+01 5.46459128e+02 4.89588505e+01 6.45034801e-02
     1.33191549e-02 4.98727184e-01 8.00078124e+02 4.54208095e+00
     7.22020084e+01 2.76100812e+04 4.69574374e+00 7.58004037e+03
     5.28223663e+01]
    


```python
Slr =  LinearRegression().fit(scaled_X_train,y_train)

print('coef_',Slr.coef_)
print('intercept_',Slr.intercept_)
```

    coef_ [-1.02255999  0.71236284  0.15252898  0.70916461 -1.75577224  3.72346696
     -0.31277636 -2.71348259  2.25858954 -1.91158736 -1.99267986  0.88477592
     -2.83238805]
    intercept_ 22.522524752475295
    


```python
 print('R2 score for train set: {:.3f}'.format(Slr.score(scaled_X_train, y_train)))
print('R2 score for test set: {:.3f}'.format(Slr.score(scaled_X_test, y_test)))
```

    R2 score for train set: 0.770
    R2 score for test set: 0.579
    

변환된 값을 이용하여 수행한 회귀분석에 대해 설명력을 출력<br>
결과를 보면 변환전과 차이가 없음. 즉, 보스톤 데이터 셋을 이용한 회귀분석에서는 변환이 별 영향을 미치지 않음을 알 수 있다.<br>
<br>
### 과대적합(Overfitting)과 과소적합(Underfitting)<br>
**Overfitting(과대적합)**: train set에 대해 너무 과하게 학습되어 test set에 대한 예측력이 떨어지는 경우<br>
**Underfitting(과소적합)**: 학습이 부족해서 train set의 구조를 잘 반영하지 못한 경우

## 다항식 features 변환 (Polynomial)
참고:http://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.PolynomialFeatures.html<br>
<br>
선형회귀분석은 기본적으로 직선으로 연관성을 찾으려는 시도라고 볼 수 있는데,<br>
주어진 독립변수들에 대해 제곱이나 변수들 간의 곱 <br>
- 다항식을 독립변수로 추가하면 다양한 곡선으로 적합이 가능하다


```python
from sklearn.preprocessing import PolynomialFeatures
poly = PolynomialFeatures(2) #2차항까지 생성하겠다.

X_train_poly = poly.fit_transform(X_train)
X_test_poly = poly.fit_transform(X_test)

print('X_train vs X_train_poly:',X_train.shape, X_train_poly.shape)
```

    X_train vs X_train_poly: (404, 13) (404, 105)
    


```python
lr = LinearRegression().fit(X_train_poly,y_train)

print('R2 score for polynomial train set: {:.3f}'.format(lr.score(X_train_poly, y_train)))
print('R2 score for polynomial test set: {:.3f}'.format(lr.score(X_test_poly, y_test)))
```

    R2 score for polynomial train set: 0.934
    R2 score for polynomial test set: 0.617
    

변환된 다항식을 이용하여 회귀분석을 수행했다.<br>
위 결과와 비교할 때, train set과 test set 모두 설명력이 향상된 것을 볼 수 있다.<br>
<u>그러나 train set와 test set의 설명력 차이가 커서 과대적합이 의심되는 상황이다.</u><br>
<br>
## 릿지회귀(Ridge regression)
과대적합을 방지하기 위한 방법으로, <br>
각 독립변수에 대한 계수가 과도하게 커지는 것을 방지한다.<br>
LinearRegression과 동일한 방법으로 사용한다.


```python
from sklearn.linear_model import Ridge
ridge = Ridge().fit(X_train_poly, y_train)

print('Ridge R2 score for polynomial train set: {:.3f}'.format(ridge.score(X_train_poly, y_train)))
print('Ridge R2 score for polynomial test set: {:.3f}'.format(ridge.score(X_test_poly, y_test)))
```

    Ridge R2 score for polynomial train set: 0.930
    Ridge R2 score for polynomial test set: 0.724
    

위 결과를 보면 사용한 후에 test set에서의 설명력이 월등히 좋아진 것을 볼 수 있다.

## 라쏘회귀(Lasso regression)
라쏘회귀는 릿지회귀와 비슷하나, <br>**계수가 0에 가까우면 0으로 만드는 성향이 있다.**<br>
즉, 특정 독립변수는 종속변수에 전혀 영향을 미치지 못하게 되며 모형에서 제외된다.


```python
from sklearn.linear_model import Lasso
import numpy as np
lasso = Lasso(max_iter=100000).fit(X_train_poly,y_train)

print('Lasso R2 score for polynomial train set: {:.3f}'.format(lasso.score(X_train_poly, y_train)))
print('Lasso R2 score for polynomial test set: {:.3f}'.format(lasso.score(X_test_poly, y_test)))
print('Used features count: {}'.format(np.sum(lasso.coef_ != 0))) #계수가 0이 아닌 독립변수의 수를 출력
```

    Lasso R2 score for polynomial train set: 0.902
    Lasso R2 score for polynomial test set: 0.772
    Used features count: 49
    

위 결과를 보면 다항식 변환을 한 후에 변수가 총 105개였으나 라쏘회귀에서는 56개만 사용된 것을 볼 수 있다.<br>
설명력은 릿지회귀보다는 떨어지지만 사용되지 않은 것에 비해서는 높다. 경고를 보면 모형이 수렴하지 못했다는 것을 알 수 있으며, 이를 해결하기 위한 방법으로 <u>iteration 수의 증가(max_iter)</u>를 제안하고 있다.<br>
iteration의 증가 외에 수렴여부의 조건(tol) 자체를 조정할 수 있다.


```python

```
